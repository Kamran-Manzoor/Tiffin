package com.kamores.tiffin;

public class Items {
    String item_name;
    String item_price;
    String item_image;
    String image_code;
    String day;
    String description;
    String service_id;
    String supllier_id;

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public void setItem_price(String item_price) {
        this.item_price = item_price;
    }

    public void setItem_image(String item_image) {
        this.item_image = item_image;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public void setSupllier_id(String supllier_id) {
        this.supllier_id = supllier_id;
    }

    public void setImage_code(String image_code) {
        this.image_code = image_code;
    }
}
