package com.kamores.tiffin;

public class ServerResponce {
    private User user;
    private Suppliers suppliers;
    private String message;
    private String result;


    public Suppliers getSuppliers() {
        return suppliers;
    }

    public String getMessage() {
        return message;
    }

    public User getUser() {
        return user;
    }

    public String getResult() {
        return result;
    }
}
