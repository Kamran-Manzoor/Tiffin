package com.kamores.tiffin.Constants;

public class Constants {
    //public static final String RETRIEVE_ALL = "allCardDataItem";
    public static final String BASE_URL = "http://192.168.10.16:8080/";
    //public static final String BASE_URL = "http://192.168.10.8:8080";
    public static final String REGISTER_SERVICE ="addServices";
    public static final String RETRIVE_DETAIL ="detailSup";
    public static final String RETRIVE_ITEMS ="allitemtoSupDay";
    public static final String ADD_ITEMS ="addItems";
    public static final String SUCCESS ="success";
    public static final String FAILURE ="failure";
    public static final String IS_LOGED_IN ="isLoggedIn";

    public static final String NAME ="name";
    public static final String EMAIL ="email";
    public static final String UNIQUE_ID ="unique_id";

    public static final String TAG ="Learn2Crack";
}